using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class DeathScript : MonoBehaviour
{
    int count = 0;

    public Text countText;

    DataManager DC;
    
    // Start is called before the first frame update
    void Start()
    {
        DC = GameObject.Find("Death").GetComponent<DataManager>();
        
        if(SceneManager.GetActiveScene().name == "Lv4_MapScene")
        {
            count = DC.count_Save;
            countText.text = "Deaths: " + count.ToString();
        }
    }

    
    private void OnTriggerEnter(Collider other)
    {



        if (other.gameObject.tag == "Enemy")
        {

            count = count + 1;
            DC.count_Save = count;
            countText.text = "Deaths: " + count;
        }


    }
}
